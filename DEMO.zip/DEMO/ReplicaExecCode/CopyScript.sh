#Copiar os ficheiros para o destino correcto
cp -a ~/Dropbox/ReplicaExecCode ~/Execution
