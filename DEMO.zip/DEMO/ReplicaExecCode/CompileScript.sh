#Move to correct folder
cd /home/igor/Execution/bin
#Compile Code
./compile-fitm.sh
