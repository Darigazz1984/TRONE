./CopyScript.sh
cd ~/Execution/
./CompileScript.sh
./ExecScript.sh $1 $2 $3
