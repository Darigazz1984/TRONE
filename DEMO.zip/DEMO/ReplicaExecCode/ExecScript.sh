NREPLICAS=$1
STARTINGID=$2
MODE=$3
cd ~/Execution/bin
./run-replicas-remote.sh $NREPLICAS $STARTINGID $MODE &
