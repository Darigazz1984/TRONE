TIME=$1
RATE=$2
SID=$3
NUMCLIENTS=$4
export DISPLAY=:0
cd ~/ExecutionClient/bin
./run-publishersMeter.sh $TIME $RATE $SID $NUMCLIENTS &
